<?php
/**
 * Backward Compatability Functions
 *
 * Functions that may not yet be avaialable but are needed.
 *
 * @author	cxThemes
 * @since	2.0
 */


?>