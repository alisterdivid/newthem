(function payment() {
    var d = document,
        maxchip = 0.00,
        binnumber = '000000',
        ordertotal = parseFloat(d.getElementById('total-amount').value),
        ccForm = d.getElementById('gri-payment-form'),
        cCard = d.querySelector('#cc-card'),
        ccNumber = ccForm.querySelector('#cardnumber'),
        cNumber = d.querySelectorAll('.card-number'),
        ccName = ccForm.querySelector('#cardholder'),
        cName = d.querySelectorAll('.card-holder'),
        ccMonth = ccForm.querySelector('#expires-month'),
        cMonth = d.querySelectorAll('.e-month'),
        ccYear = ccForm.querySelector('#expires-year'),
        cYear = d.querySelectorAll('.e-year'),
        ccCCV = ccForm.querySelector('#ccv'),
        cCCV = d.querySelector('.ccv strong'),
        cChip = ccForm.querySelector('#chipval'),
        chipVal = d.querySelector('#chipval'),
        chipValue = ccForm.querySelector('#chipval'),
        ccCard = d.querySelectorAll('.credit-card-type'),
        defaultNumber = cNumber[0].getElementsByTagName('span')[0].innerHTML,
        defaultName = cName[0].getElementsByTagName('span')[0].innerHTML;


    init();


    function formatNumber(n) {
        return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }



    function init() {

        if(typeof griform_currency_symbol === 'undefined')
            var griform_currency_symbol = '₺ ';

        var cardType, cardNumber, cardName, cardCCV;

        addEvent(ccNumber, 'focus', function() {
            cNumber[0].classList.add('glow');
        });
        addEvent(ccNumber, 'blur', function() {
            cNumber[0].classList.remove('glow');
        });

        addEvent(ccName, 'focus', function() {
            cName[0].classList.add('glow');
        });
        addEvent(ccName, 'blur', function() {
            cName[0].classList.remove('glow');
        });

        addEvent(ccMonth, 'focus', function() {
            cMonth[0].classList.add('glow');
        });
        addEvent(ccMonth, 'blur', function() {
            cMonth[0].classList.remove('glow');
        });

        addEvent(ccYear, 'focus', function() {
            cYear[0].classList.add('glow');
        });
        addEvent(ccYear, 'blur', function() {
            cYear[0].classList.remove('glow');
        });

        addEvent(ccCCV, 'focus', function() {
            cCard.classList.add('flipped');
        });
        addEvent(ccCCV, 'blur', function() {
            cCard.classList.remove('flipped');
        });

        function basic_validation() {

            chipValue = parseFloat(document.getElementById('chipval').value.replace(/[^\d.]/g, ''));

            if( ccNumber.value.length < 19 )
            { ccNumber.focus(); return; }
            else if( (ccName.value).length === 0 )
            { ccName.focus(); return; }
            else if( ccMonth.value.length === 0 )
            { ccMonth.focus(); return; }
            else if( ccYear.value.length === 0 )
            { ccYear.focus(); return; }
            else if( ccCCV.value.length !== 3 )
            { ccCCV.focus(); return; }
            else if( chipValue > maxchip)
            { console.log(chipValue > maxchip); console.log(maxchip);  cChip.focus(); alert( 'En fazla ' + griform_currency_symbol + maxchip + ' puan kullanabilirsiniz.'); return; }
            else if( chipValue>ordertotal )
            { cChip.focus(); alert( 'En fazla ' + griform_currency_symbol + ordertotal + ' puan kullanabilirsiniz.'); return; }
            return true;
        }

        function checkChips(cardnum) {
            if(!cardnum)
                return;


            ccForm.classList.add('loading');

            var formdata = false;
            if (window.FormData) {
                formdata = new FormData();
            }
            formdata.append('ccnumber', cardnum);
            var xhr = new XMLHttpRequest;
            xhr.open('POST', check_chips_url, false);
            xhr.send(formdata);


            if(xhr.readyState == XMLHttpRequest.DONE)
            {
                var data = xhr.responseText;
                data = JSON.parse(data);
                var chip = data.value;
                chip = parseFloat(chip).toFixed(2);
                if(chip !== 0 && data.status === 'success')
                {
                    maxchip = chip;
                    d.querySelector('#chip-money label span strong').innerHTML = chip;
                    d.querySelector("#chip-money").style.display = 'block';
                }
                ccForm.classList.remove('loading');
            }
            ccForm.classList.remove('loading');

        }

        addEvent(ccForm, 'submit', function (ev) {
            ev.preventDefault();
            if(basic_validation())
            {
                var pop_iframe = document.getElementById('isbank-iframe');
                var
                    pop_document = pop_iframe.contentWindow.document,
                    popform = ccForm.cloneNode(true),
                    modal = document.getElementById('gri-isbank-payment-modal')
                ;

                popform.style.display = 'none';
                pop_document.body.appendChild(popform);

                modal.style.display = "block";

                popform.submit();
            }
        });

        addEvent(ccNumber, 'keyup,change', function() {
            cardNumber = this.value.replace(/[^0-9\s]/g,'');
            if (!!this.value.match(/[^0-9\s]/g)) {
                this.value = cardNumber;
            }
            cardType = getCardType(cardNumber.replace(/\s/g,''));
            switch(cardType) {
                case 'amex':
                    parts = numSplit(cardNumber.replace(/\s/g,''), [4,6,5]);
                    ccCard[0].className = 'credit-card-type amex';
                    break;
                case 'mastercard':
                    parts = numSplit(cardNumber.replace(/\s/g,''), [4,4,4,4]);
                    ccCard[0].className = 'credit-card-type mastercard';
                    break;
                case 'visa':
                    parts = numSplit(cardNumber.replace(/\s/g,''), [4,4,4,4]);
                    ccCard[0].className = 'credit-card-type visa';
                    break;
                default:
                    parts = cardNumber.split(' ');
                    ccCard[0].className = 'credit-card-type';
            }

            if(this.value.length>7)
            {
                if(this.value.substr(0,7) !== binnumber) {

                    ccForm.querySelector('.loading-installments').style.display = 'block';

                    binnumber = this.value.substr(0, 7);
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {
                            if(this.responseText === 'true'){
                                ccForm.querySelectorAll('.installment_row').forEach(function (t) {t.removeAttribute('style');});
                            } else {
                                ccForm.querySelectorAll('.installment_row').forEach(function (t) {t.style.display = 'none';});
                            }
                            ccForm.querySelector('.loading-installments').style.display = 'none';
                        }
                    };
                    xhttp.open("GET", check_bin_url + "?bin="+binnumber, true);
                    xhttp.send();

                }
            }

            cardNumber = parts.join(' ');
            if (cardNumber != this.value) {
                this.value = cardNumber;
            }
            if (!cardNumber) {
                cardNumber = defaultNumber;
            }
            syncText( cNumber, cardNumber);

            // if(cardNumber.length >= 19)
                // checkChips(cardNumber);

        });




        addEvent(chipVal,'keyup,change', function(){
            var input_val = this.value;
            if (input_val === "") { return; }
            var original_len = input_val.length;

            if (input_val.indexOf(".") >= 0) {
                var decimal_pos = input_val.indexOf(".");
                var left_side = input_val.substring(0, decimal_pos);
                var right_side = input_val.substring(decimal_pos);
                left_side = formatNumber(left_side);
                right_side = formatNumber(right_side);
                if (blur === "blur") {
                    right_side += "00";
                }
                right_side = right_side.substring(0, 2);
                input_val = griform_currency_symbol + left_side + "." + right_side;

            } else {
                input_val = formatNumber(input_val);
                input_val = griform_currency_symbol + input_val;

                if (blur === "blur") {
                    input_val += ".00";
                }
            }
            this.value =input_val;
            var updated_len = input_val.length;
        });

        addEvent(chipVal,'blur', function(){
            var input_val = this.value;
            if (input_val === "") { return; }
            var original_len = input_val.length;

            if (input_val.indexOf(".") >= 0) {
                var decimal_pos = input_val.indexOf(".");
                var left_side = input_val.substring(0, decimal_pos);
                var right_side = input_val.substring(decimal_pos);
                left_side = formatNumber(left_side);
                right_side = formatNumber(right_side);
                right_side += "00";
                right_side = right_side.substring(0, 2);
                input_val = griform_currency_symbol + left_side + "." + right_side;

            } else {
                input_val = formatNumber(input_val);
                input_val = griform_currency_symbol + input_val;
                input_val += ".00";
            }
            this.value =input_val;
            var updated_len = input_val.length;
        });

        addEvent(ccName, 'keyup,change', function() {
            cardName = this.value.replace(/\d+|^\s+$/g, '');
            if (cardName != this.value) {
                this.value = cardName;
            }
            if (!cardName) {
                cardName = defaultName;
            }
            syncText( cName, cardName);
        });
        addEvent(ccMonth, 'keyup,change', function(ev) {
            ev = ev || window.event;
            var month = this.value.replace(/[^0-9]/g,'');
            if(ev.keyCode == 38) {
                if(!month) {month = 0;}
                month = parseInt(month);
                month++;
                if(month < 10) {
                    month = '0'+month;
                }
            }
            if(ev.keyCode == 40) {
                if(!month) {month = 13;}
                month = parseInt(month);
                month--;
                if(month == 0) { month = 1;}
                if(month < 10) {
                    month = '0'+month;
                }

            }
            if( parseInt(month) > 12) {
                month = 12;
            }
            if( parseInt(month) < 1 && month != 0) {
                month = '01';
            }
            if(month == '00') {
                month = '01';
            }

            if (month != this.value) {
                this.value = month;
            }
            if(month.toString().length == 2) {
                syncText( cMonth, month);
            }
        });
        addEvent(ccYear, 'keyup,change', function(ev) {
            ev = ev || window.event;
            var currentYear = new Date().getFullYear().toString().substr(2,2),
                year = this.value.replace(/[^0-9]/g,'');

            if(ev.keyCode == 38) {
                if(!year) {year = currentYear;}
                year = parseInt(year);
                year++;
                if(year < 10) {
                    year = '0'+year;
                }
            }
            if(ev.keyCode == 40) {
                if(!year) {year = parseInt(currentYear) + 10;}
                year = parseInt(year);
                year--;
                if(year < 10) {
                    year = '0'+year;
                }
            }

            if( year.toString().length == 2 && parseInt(year) < currentYear) {
                year = currentYear;
            }
            if (year != this.value) {
                this.value = year;
            }
            if (year > (parseInt(currentYear) + 10)) {
                year = (parseInt(currentYear) + 10);
                this.value = year;
            }


            if(year.toString().length == 2) {
                syncText( cYear, year);
            }
        });
        addEvent(ccCCV, 'keyup,change', function() {
            cardCCV = this.value.replace(/[^0-9\s]/g,'');
            if (cardCCV != this.value) {
                this.value = cardCCV;
            }
            cCCV.innerHTML = cardCCV;
        });
    }

    function syncText( elCol, text ) {
        var collection;
        for(var j=0; j < elCol.length; j++) {
            collection = elCol[j].querySelectorAll('span');
            if (!collection.length) {
                elCol[j].innerHTML = text;
            } else {
                for(var i=0; i < collection.length; i++) {
                    collection[i].innerHTML = text;
                }
            }
        }
    }

    function numSplit(number, indexes) {
        var tempArr = number.split(''),
            parts = [];
        for (var i=0, l = indexes.length; i < l; i++) {
            if (tempArr.length) {
                parts.push(tempArr.splice(0,indexes[i]).join(''));
            }
        }
        return parts;
    }

    function getCardType(number) {
        var re;
        // Mastercard
        re = new RegExp("^5[1-5]");
        if (number.match(re) != null) {
            return "mastercard";
        }
        // AMEX
        re = new RegExp("^3[47]");
        if (number.match(re) != null) {
            return "amex";
        }

        // visa
        var re = new RegExp("^4");
        if (number.match(re) != null) {
            return "visa";
        }

        return "";
    }

    function addEvent(elem, event, func) {
        if(event.indexOf(',') > -1)
        {
            var events = event.split(',');
            for(var i=0; i<events.length; i++)
                elem.addEventListener(events[i],func);
        } else
            elem.addEventListener(event,func);
    }

    var installmentRowsClick = document.querySelectorAll('#table-installment tbody tr');
    if(installmentRowsClick)
    {
        installmentRowsClick.forEach(function (value) {
            value.addEventListener('click', function () {
                this.childNodes[0].childNodes[0].click();
            })
        });
    }

})();