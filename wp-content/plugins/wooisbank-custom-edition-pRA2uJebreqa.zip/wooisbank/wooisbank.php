<?php
/*
Plugin Name: grilabs - Isbank Payment Gateway
Plugin URI: https://www.gri.net/wordpress-eklenti/isbank-sanal-pos
Description: Turkiye Is Bankasi Payment Gateway for WooCommerce (EST)
Version: 1.0
Author: grilabs
Author URI: http://www.grilabs.com/
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function isbank_init_gateway()
{
    if (class_exists('WC_Payment_Gateway') && version_compare(WC_VERSION, '2.1', '>='))
        include_once('isbank-gateway.php');
    $plugin_rel_path = basename( dirname( __FILE__ ) ) . '/languages';
    load_plugin_textdomain( 'IsBank', false, $plugin_rel_path );
}
add_action('plugins_loaded', 'isbank_init_gateway', 0);