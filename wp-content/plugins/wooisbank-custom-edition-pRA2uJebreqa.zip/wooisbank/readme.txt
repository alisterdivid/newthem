==== grilabs - WooCommerce IsBank Sanal POS ====
Tags: woocommerce, isbank, payments, virtual pos, 3d secure
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 0.30

== Installation ==

1. Install the "grilabs - IsBank WooCommerce Sanal POS" plugin.
2. Activate the plugin
3. Go to the WooCommerce Settings Page 
4. Access Payment Gateways Tab
5. Select "grilabs - IsBank wooCommerce Sanal POS"
6. Check the Enable/Disable Checkbox.
7. Enter the settings that you would like you to use