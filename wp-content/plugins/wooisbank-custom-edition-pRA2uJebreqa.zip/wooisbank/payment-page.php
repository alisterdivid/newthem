<div id="gri-isbank-payment-modal">
    <iframe id="isbank-iframe" frameborder="0" src="" width="400" height="500"></iframe>
</div>

<div class="gri-payment-form--div">
    <div class="box">
        <header>
            <div class="card" id="cc-card">
                <div class="flipper">
                    <div class="front">
                        <div class="shine"></div>
                        <div class="shadow"></div>
                        <div class="card-bg">
                            <img src="<?php echo $this->url['assets'].'/images/cc-front-bg.png'; ?>" />
                        </div>
                        <div class="card-content">
                            <div class="credit-card-type"></div>
                            <div class="card-number">
                                <span>1234 1234 1234 1234</span>
                                <span>1234 1234 1234 1234</span>
                            </div>
                            <div class="card-holder">
                                <em><?php echo __('Card Holder', 'IsBank') ?></em>
                                <span><?php echo __('NAME SURNAME', 'IsBank') ?></span>
                                <span><?php echo __('NAME SURNAME', 'IsBank') ?></span>
                            </div>
                            <div class="validuntil">
                                <em><?php echo __('VALID<br>THRU', 'IsBank') ?></em>
                                <div class="e-month">
                                    <span><?php echo __('MM', 'IsBank') ?></span>
                                    <span><?php echo __('MM', 'IsBank') ?></span>
                                </div>

                                <div class="e-divider">
                                    <span>/</span>
                                    <span>/</span>
                                </div>

                                <div class="e-year">
                                    <span><?php echo __('YY', 'IsBank') ?></span>
                                    <span><?php echo __('YY', 'IsBank') ?></span>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="back">
                        <div class="shine"></div>
                        <div class="shadow"></div>
                        <div class="card-bg">
                            <img src="<?php echo $this->url['assets'].'/images/cc-back-bg-new.png'; ?>" />
                        </div>
                        <div class="ccv">
                            <em></em>
                            <strong>***</strong>
                        </div>
                        <div class="card-content">
                            <div class="card-number">
                                <span>1234 1234 1234 1234</span>
                                <span>1234 1234 1234 1234</span>
                            </div>
                            <div class="card-holder">
                                <span><?php echo __('NAME SURNAME', 'IsBank') ?></span>
                                <span><?php echo __('NAME SURNAME', 'IsBank') ?></span>
                            </div>
                            <div class="validuntil">
                                        <span>
                                          <strong class="e-month"><?php echo __('MM','IsBank') ?></strong> / <strong class="e-year"><?php echo __('YY', 'IsBank') ?></strong>
                                        </span>

                                <span>
                                          <strong class="e-month"><?php echo __('MM','IsBank') ?></strong> / <strong class="e-year"><?php echo __('YY', 'IsBank') ?></strong>
                                        </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <form id="gri-payment-form" action="<?php echo ($payment_url) ?>" method="post" class="">
            <script type="text/javascript">var check_bin_url = "<?php echo $bincheck_url; ?>";</script>
            <div class="spinner"><img src="<?php echo $this->url['assets'].'/images/Spin.gif'; ?>" width="60"></div>

            <div class="form-content">
                <div class="field">
                    <label for="cardnumber"><?php echo __('Card Number', 'IsBank') ?></label>
                    <input type="tel" id="cardnumber" maxlength="20" name="ccnumber" />
                    <span class="focus-bar"></span>
                    <div class="loading-installments"><img src="<?php echo $this->url['assets'].'/images/spinner.gif'; ?>" width="20"></div>
                </div>
                <div class="field">
                    <label for="cardholder"><?php echo __('Card Holder', 'IsBank') ?></label>
                    <input type="text" autocorrect="off" spellcheck="false" id="cardholder" maxlength="25" name="ccholder" />
                    <span class="focus-bar"></span>
                </div>
                <div class="field-group">
                    <div class="col-50">
                        <label for="expires-month"><?php echo __('Expiry Date', 'IsBank') ?></label>
                        <div class="field expire-date">
                            <div>
                                <input type="tel" id="expires-month" placeholder="<?php echo __('MM', 'IsBank') ?>" allowed-pattern="[0-9]" maxlength="2" name="ccmonth">
                                <span class="focus-bar"></span>
                            </div>
                            <div class="divider">/</div>
                            <div>
                                <input type="tel" id="expires-year" placeholder="<?php echo __('YY', 'IsBank') ?>" allowed-pattern="[0-9]" maxlength="2" name="ccyear">
                                <span class="focus-bar"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="field ccv">
                            <label for="ccv"><?php echo __('CCV', 'IsBank') ?></label>
                            <input type="tel" id="ccv" autocomplete="off" maxlength="3" name="ccccv" placeholder="•••" />
                            <span class="focus-bar"></span>
                        </div>
                    </div>
                </div>



                <div class="field-group" id="chip-money"
                     style="display: none;"
                >
                    <div class="">
                        <div class="field">
                            <input type="hidden" id="total-amount" value="<?php echo floatval($order->get_total()); ?>">
                            <input type="text" name="usechip" id="chipval" value="0.00">
                            <label>Puan kullan: <span>(<strong></strong> <?php
                                    echo get_woocommerce_currency_symbol($order->currency);
                                    ?> kullanılabilir)</span></label>
                        </div>
                    </div>
                </div>

                <div class="installment-row">
                    <table class="table-installment" id="table-installment">
                        <thead>
                        <tr>
                            <th>&nbsp;</th>
                            <th><?php echo __('Installment', 'IsBank') ?></th>
                            <th><?php echo __('Total', 'IsBank') ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr><td><input type="radio" name="installment" value="1" /></td><td class="installment-text-td"><?php echo __('Advance', 'IsBank') ?></td><td class="price-td"><?php echo sprintf('%.2f',$order_price) . ' ' . $currency_label ?></td></tr>
                        <?php for($i=2; $i<=12; $i++){
                            $price_new_val = $this->calcInstallment($order_price,$i);
                            if($price_new_val !== false) {
                                echo '<tr class="installment_row" style="display:none">' .
                                    '<td><input type="radio" name="installment" value="'.$i.'"></td>' .
                                    '<td class="installment-text-td">' . $i . ' '. __('Installments','IsBank').'</td>' .
                                    '<td class="price-td">' . sprintf("%.2f", $price_new_val) . ' ' . $currency_label . '</td>' .
                                    '</tr>';
                            }
                        } ?>
                        </tbody>

                    </table>
                </div>

                <div class="field" style="text-align: center;">
                    <label for="3d_pay">
                        <input
                            id="3d_pay"
                            type="checkbox" name="3d_pay" value="on" checked> <?php echo __('Use 3D Secure','IsBank') ?>
                    </label>
                </div>

                <button><span><?php echo __('Pay', 'IsBank') ?></span></button>
            </div>
            <input type="hidden" name="order_id" value="<?php echo $order->id; ?>">
        </form>
    </div>
</div>

<script type="text/javascript" src="<?php echo $this->url['assets'].'/js/gripaymentform.js'; ?>"></script>